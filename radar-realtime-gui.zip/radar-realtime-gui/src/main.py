import sys
from PySide6 import QtWidgets, QtCore

from src.radar_feed import RadarFeed
from src.radar_gui import RadarMap, TargetInfoPanel


class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Radar Realtime GUI")
        self.resize(1200, 700)

        self.map = RadarMap()
        self.info = TargetInfoPanel()

        central = QtWidgets.QWidget()
        layout = QtWidgets.QHBoxLayout(central)
        layout.addWidget(self.map, 2)
        layout.addWidget(self.info, 1)
        self.setCentralWidget(central)

        self.feed = RadarFeed()
        self._last_targets = []

        self.map.targetClicked.connect(self.on_target_clicked)

        self.timer = QtCore.QTimer(self)
        self.timer.timeout.connect(self.refresh_radar)
        self.timer.start(200)

    def refresh_radar(self):
        targets = self.feed.generate_targets()
        self._last_targets = targets
        self.map.update_targets(targets)

    def on_target_clicked(self, track_id: int):
        for t in self._last_targets:
            if t.track_id == track_id:
                self.info.show_target(t)
                break


def main():
    app = QtWidgets.QApplication(sys.argv)
    w = MainWindow()
    w.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
