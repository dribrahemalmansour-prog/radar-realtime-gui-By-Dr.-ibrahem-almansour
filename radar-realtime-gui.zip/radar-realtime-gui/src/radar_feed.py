import random
from typing import List
from src.model import Target


class RadarFeed:
    """Simulates incoming radar data."""

    def __init__(self, n_targets: int = 8):
        self.n_targets = n_targets
        self._tick = 0

    def generate_targets(self) -> List[Target]:
        self._tick += 1
        targets = []
        for i in range(self.n_targets):
            base_x = 400 + 200 * random.random()
            base_y = 300 + 200 * random.random()
            jitter = (self._tick % 20) * 2
            x = (base_x + jitter) % 1000
            y = (base_y + jitter) % 1000
            targets.append(
                Target(
                    track_id=i,
                    x=x,
                    y=y,
                    velocity=120 + random.random() * 30,
                    heading=random.randint(0, 359),
                    rcs=10 + random.random() * 20,
                )
            )
        return targets
