from PySide6 import QtWidgets, QtGui, QtCore
from typing import List
from src.model import Target


class RadarMap(QtWidgets.QGraphicsView):
    targetClicked = QtCore.Signal(int)  # track_id

    def __init__(self, parent=None):
        super().__init__(parent)
        self.scene = QtWidgets.QGraphicsScene(self)
        self.setScene(self.scene)
        self.setRenderHints(
            QtGui.QPainter.Antialiasing | QtGui.QPainter.SmoothPixmapTransform
        )
        self.setSceneRect(0, 0, 1000, 1000)
        self._target_items = {}

        bg = self.scene.addRect(0, 0, 1000, 1000, pen=QtGui.QPen(QtCore.Qt.NoPen))
        bg.setBrush(QtGui.QColor("#102030"))

    def update_targets(self, targets: List[Target]):
        alive_ids = {t.track_id for t in targets}
        for tid in list(self._target_items.keys()):
            if tid not in alive_ids:
                self.scene.removeItem(self._target_items[tid])
                del self._target_items[tid]

        for t in targets:
            if t.track_id not in self._target_items:
                item = self.scene.addEllipse(
                    0, 0, 14, 14, pen=QtGui.QPen(QtGui.QColor("lime")),
                    brush=QtGui.QBrush(QtGui.QColor("lime"))
                )
                item.setData(0, t.track_id)
                item.setFlag(QtWidgets.QGraphicsItem.ItemIsSelectable, True)
                self._target_items[t.track_id] = item
            item = self._target_items[t.track_id]
            item.setPos(t.x, t.y)

    def mousePressEvent(self, event):
        pos = self.mapToScene(event.pos())
        items = self.scene.items(pos)
        for it in items:
            tid = it.data(0)
            if tid is not None:
                self.targetClicked.emit(int(tid))
                break
        super().mousePressEvent(event)


class TargetInfoPanel(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setLayout(QtWidgets.QFormLayout())
        self.labels = {
            "track_id": QtWidgets.QLabel("-"),
            "x": QtWidgets.QLabel("-"),
            "y": QtWidgets.QLabel("-"),
            "velocity": QtWidgets.QLabel("-"),
            "heading": QtWidgets.QLabel("-"),
            "rcs": QtWidgets.QLabel("-"),
        }
        for name, lbl in self.labels.items():
            self.layout().addRow(name, lbl)

    def show_target(self, target: Target | None):
        if target is None:
            for lbl in self.labels.values():
                lbl.setText("-")
            return
        self.labels["track_id"].setText(str(target.track_id))
        self.labels["x"].setText(f"{target.x:.1f}")
        self.labels["y"].setText(f"{target.y:.1f}")
        self.labels["velocity"].setText(f"{target.velocity:.1f} kt")
        self.labels["heading"].setText(f"{target.heading}°")
        self.labels["rcs"].setText(f"{target.rcs:.1f} dBsm")
