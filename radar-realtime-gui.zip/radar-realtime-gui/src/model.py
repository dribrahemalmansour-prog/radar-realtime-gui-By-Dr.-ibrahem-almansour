from dataclasses import dataclass
from typing import List


@dataclass
class Target:
    track_id: int
    x: float
    y: float
    velocity: float
    heading: float
    rcs: float  # radar cross section


def targets_to_dicts(targets: List[Target]):
    return [t.__dict__ for t in targets]
